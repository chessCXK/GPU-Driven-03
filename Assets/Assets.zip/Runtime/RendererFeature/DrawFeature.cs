using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class DrawInstanceDirectFeature : ScriptableRendererFeature
{

    public int lod;
    public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRenderingOpaques;

    private DrawInstanceDirectPass m_pass;
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        renderer.EnqueuePass(m_pass);
    }

    public override void Create()
    {
        m_pass = new DrawInstanceDirectPass(renderPassEvent, this);
    }
}
public class DrawInstanceDirectPass : ScriptableRenderPass
{
    private ProfilingSampler m_profilingSampler = new ProfilingSampler("HZBDrawPass");

    public DrawInstanceDirectPass(RenderPassEvent renderPassEvent, DrawInstanceDirectFeature df)
    {
        this.renderPassEvent = renderPassEvent;
    }
    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        HiZGlobelManager m_gManager = HiZGlobelManager.Instance;
        if (!m_gManager.IsSure)
        {
            return;
        }

#if UNITY_EDITOR
        if (renderingData.cameraData.camera.name == "Preview Camera")
            return;
#endif
        //TODO
        CommandBuffer cmd = CommandBufferPool.Get();
        List<uint> args = new List<uint>();
        using (new ProfilingScope(cmd, m_profilingSampler))
        {
            Shader.SetGlobalBuffer(HZBBufferName._ResultBuffer, m_gManager.ResultBuffer);

            List<VegetationList> allVegetation = m_gManager.VData.allObj;

            List<VegetationAsset> assetList = m_gManager.VData.assetList;

            List<ClusterKindData> clusterKindData = m_gManager.VData.clusterKindData;

#if UNITY_EDITOR
            if (m_gManager.enableDebugBuffer || renderingData.cameraData.camera.name == "SceneCamera")
            {
                int argsCount = -1;
                foreach (var vegetationList in allVegetation)
                {
                    VegetationAsset asset = assetList[vegetationList.assetId];
                    for (int lodIndex = 0; lodIndex < asset.lodAsset.Count; lodIndex++)
                    {
                        var lod = asset.lodAsset[lodIndex];
                        argsCount++;
#if UNITY_EDITOR
                        lod.materialRun.SetBuffer(HZBBufferName._InstanceBuffer, lod.buffer);
                        ClusterKindData cKindData = clusterKindData[vegetationList.clusterData[0].clusterKindIndex];
                        lod.materialRun.SetFloat("_resultOffset", cKindData.kindResultStart + vegetationList.clusterData.Count * lodIndex);
#endif
                        cmd.DrawMeshInstancedIndirect(lod.mesh, 0, lod.materialRun, 0, m_gManager.ArgsBuffer, sizeof(uint) * 5 * argsCount);
                    }
                }
            }
            else
#endif
            {
                VegetationCeilGather ceilGather = m_gManager.VData.preDCCeils.ceilGather;
                VegetationCeil column = ceilGather.GetCeil(renderingData.cameraData.camera.transform.position);
                if(column != null)
                {
                    Debug.Log(column.dcIndexList.Count);
                    foreach (var drawIndex in column.dcIndexList)
                    {
                        int vegetationIndex = drawIndex.x;
                        int lodIndex = drawIndex.y;

                        var vegetationList = allVegetation[vegetationIndex];
                        VegetationAsset asset = assetList[vegetationList.assetId];
                        var lod = asset.lodAsset[lodIndex];

                        ClusterKindData cKindData = clusterKindData[vegetationList.clusterData[0].clusterKindIndex];
                        int argsCount = cKindData.argsIndex + lodIndex;
#if UNITY_EDITOR
                        lod.materialRun.SetBuffer(HZBBufferName._InstanceBuffer, lod.buffer);
                        lod.materialRun.SetFloat("_resultOffset", cKindData.kindResultStart + vegetationList.clusterData.Count * lodIndex);
#endif
                        cmd.DrawMeshInstancedIndirect(lod.mesh, 0, lod.materialRun, 0, m_gManager.ArgsBuffer, sizeof(uint) * 5 * argsCount);
                    }
                }
                
            }
        }
        //ִ��
        context.ExecuteCommandBuffer(cmd);

        //����
        CommandBufferPool.Release(cmd);
    }


}