using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[ExecuteInEditMode]
public class HiZDataLoader : MonoBehaviour
{
    public VegetationData data;
    public void OnEnable()
    {
        HiZGlobelManager.Instance.CreateComputeBuffer(data);
    }
    public void OnDisable()
    {
        HiZGlobelManager.Instance.DisposeComputeBuffer();
    }
    private void Update()
    {
        var ar = GraphicsSettings.currentRenderPipeline;
        var br = GraphicsSettings.renderPipelineAsset;
        Debug.Log("chess");
    }
}
